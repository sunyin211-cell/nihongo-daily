日本語 Daily v9 手机/PWA版

功能：
- 基于 v8 的完整学习内容与测试逻辑
- 手机竖屏优化
- 可安装到手机主屏幕
- Service Worker 离线缓存
- localStorage 保存学习进度和测试状态

使用：
1. 将整个文件夹上传到支持 HTTPS 的静态网站。
2. 手机浏览器打开 index.html 对应网页。
3. iPhone：Safari -> 分享 -> 添加到主屏幕。
4. Android：Chrome -> 菜单 -> 安装应用/添加到主屏幕。

注意：直接在手机上打开 file://index.html 可以学习，但不能完整启用 PWA 安装和 Service Worker。
